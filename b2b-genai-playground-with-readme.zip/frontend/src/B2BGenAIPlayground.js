import React, { useState } from 'react';
import axios from 'axios';

export default function B2BGenAIPlayground() {
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState('');

  const handleGenerate = async () => {
    try {
      const res = await axios.post('http://localhost:5000/api/generate', { prompt });
      setResponse(res.data.output);
    } catch (error) {
      console.error('Error generating content:', error);
    }
  };

  return (
    <div className="bg-white min-h-screen p-8 font-sans">
      <header className="mb-12">
        <div className="text-3xl font-bold text-black">
          <span className="text-black">B2B Gen</span>
          <span className="text-yellow-600">AI</span> <span>Adoption</span>
        </div>
        <h1 className="text-4xl mt-4 font-semibold text-black">
          Time flies when you <span className="text-yellow-600">B2B GenAI</span>.
        </h1>
      </header>

      <main className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-green-900 text-white p-6 rounded-2xl shadow-lg">
          <div className="text-2xl font-bold mb-2">Discovery Questions</div>
          <p className="text-sm">
            Generate tailored questions to engage prospects and uncover their needs
          </p>
        </div>

        <div className="bg-white border border-green-900 text-black p-6 rounded-2xl shadow-lg">
          <div className="text-2xl font-bold text-yellow-700 mb-2">Pain Point Library</div>
          <p className="text-sm">
            Browse common pain points that relate to your solution or offering
          </p>
        </div>

        <div className="bg-green-900 text-white p-6 rounded-2xl shadow-lg">
          <div className="text-2xl font-bold mb-2">Storytelling</div>
          <p className="text-sm">
            Craft compelling stories to communicate the power of your solution
          </p>
        </div>

        <div className="bg-white border border-green-900 text-black p-6 rounded-2xl shadow-lg">
          <div className="text-2xl font-bold text-yellow-700 mb-2">Active Listening</div>
          <p className="text-sm">
            Improve your listening skills for more effective sales conversations
          </p>
        </div>
      </main>

      <section className="bg-gray-100 p-6 rounded-2xl mb-8">
        <h2 className="text-2xl font-semibold mb-2 text-green-900">Free Prompt Builder</h2>
        <textarea
          className="w-full p-4 border border-green-900 rounded-xl mb-4"
          rows="4"
          placeholder="Enter your custom prompt here..."
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
        ></textarea>
        <button
          onClick={handleGenerate}
          className="bg-yellow-600 text-white py-2 px-6 rounded-xl hover:bg-yellow-700"
        >
          Generate
        </button>
        {response && (
          <div className="mt-4 p-4 bg-white border border-green-900 rounded-xl">
            <strong className="text-green-900">Generated Output:</strong>
            <p className="mt-2 text-sm text-black">{response}</p>
          </div>
        )}
      </section>
    </div>
  );
}
