# 🚀 Deployment Guide: B2B GenAI Adoption App

This guide will walk you through deploying both the **frontend** (React + Tailwind CSS) on **Vercel** and the **backend** (Node.js + Express + OpenAI) on **Render**.

---

## 🌐 1. Frontend on Vercel

### ✅ Step 1: Push Frontend to GitHub

If not done already:

```bash
cd frontend
git init
git remote add origin https://github.com/Luke19881127/b2b-genai-playground.git
git add .
git commit -m "Frontend initial commit"
git push -u origin main
```

> You can also manually create the `b2b-genai-playground` repo on GitHub and push.

---

### ✅ Step 2: Deploy on Vercel

1. Go to [https://vercel.com](https://vercel.com)
2. Sign in with GitHub
3. Click **“New Project”**
4. Import the `b2b-genai-playground` repo
5. Configure:
   - **Framework Preset**: React
   - **Root Directory**: `frontend`
6. Click **Deploy**

---

## ⚙️ 2. Backend on Render

### ✅ Step 1: Push Backend to GitHub

```bash
cd ../backend
git init
git remote add origin https://github.com/Luke19881127/b2b-genai-backend.git
git add .
git commit -m "Backend initial commit"
git push -u origin main
```

> Or create the `b2b-genai-backend` repo manually and push code.

---

### ✅ Step 2: Deploy on Render

1. Go to [https://render.com](https://render.com)
2. Create account or sign in
3. Click **“New Web Service”**
4. Connect to your `b2b-genai-backend` GitHub repo
5. Fill in:
   - **Build Command**: `npm install`
   - **Start Command**: `node server.js`
6. Under **Environment Variables**:
   - `OPENAI_API_KEY`: your actual OpenAI key
7. Click **Deploy**

> You’ll get a live API URL like `https://b2b-genai-backend.onrender.com`

---

## 🔄 Final Integration

Update `frontend/src/App.jsx`:

```js
const res = await axios.post('https://your-backend-url.onrender.com/api/generate', { prompt });
```

Commit and push changes → Vercel will auto-redeploy.

---

## ✅ Done!

You now have a live GenAI-powered B2B sales assistant with:

- ✨ Vercel-hosted React frontend
- ⚙️ Render-hosted Node.js + GPT-4 backend
